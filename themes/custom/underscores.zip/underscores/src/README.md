This directory is used to implement various Bootstrap annotated plugins.

Please refer to the [Plugin System](<!-- @url plugins -->) topic for more info.
